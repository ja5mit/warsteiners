Hello Welcome to the program that helps you find a spanning tree using Breadth first search.

Use the the file called input.txt to enter the number of verticies followed by the adjacency matrix
where the values of the matrix are seperated by a space and rows are seperated by a new line.

for example: 
6
0 1 1 0 0 0
1 0 0 1 0 0
1 0 0 1 0 0
0 1 1 0 1 0
0 0 0 1 0 1
0 0 0 0 1 0
